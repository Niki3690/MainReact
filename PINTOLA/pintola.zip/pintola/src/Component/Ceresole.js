// import React from "react";
// import "./Ceresole.css"


// const Ceresole = () => {
//   return (
//     <>
//       <div id="carouselExampleIndicators" class="carousel slide">
//         <div class="carousel-indicators">
//           <button
//             type="button"
//             data-bs-target="#carouselExampleIndicators"
//             data-bs-slide-to="0"
//             class="active"
//             aria-current="true"
//             aria-label="Slide 1"
//           ></button>
//           <button
//             type="button"
//             data-bs-target="#carouselExampleIndicators"
//             data-bs-slide-to="1"
//             aria-label="Slide 2"
//           ></button>
//           <button
//             type="button"
//             data-bs-target="#carouselExampleIndicators"
//             data-bs-slide-to="2"
//             aria-label="Slide 3"
//           ></button>
//         </div>
//         <div class="carousel-inner">
//           <div class="carousel-item active">
//             <img
//               src="https://www.pintola.in/cdn/shop/collections/Website-Banner_Desktop_1200x.jpg?v=1692365168"
//               class="d-block w-100"
//               alt="..."
//             />
//           </div>
//           <div class="carousel-item">
//             <img
//               src="https://www.pintola.in/cdn/shop/files/Choco_400gm_600x.jpg?v=1687856862"
//               class="d-block w-100"
//               alt="..."
//             />
//           </div>
//           <div class="carousel-item">
//             <img
//               src="https://www.pintola.in/cdn/shop/files/Desktop_02_1400x.png?v=1691845083"
//               class="d-block w-100"
//               alt="..."
//             />
//           </div>
//         </div>
//         <button
//           class="carousel-control-prev"
//           type="button"
//           data-bs-target="#carouselExampleIndicators"
//           data-bs-slide="prev"
//         >
//           <span class="carousel-control-prev-icon" aria-hidden="true"></span>
//           <span class="visually-hidden">Previous</span>
//         </button>
//         <button
//           class="carousel-control-next"
//           type="button"
//           data-bs-target="#carouselExampleIndicators"
//           data-bs-slide="next"
//         >
//           <span class="carousel-control-next-icon" aria-hidden="true"></span>
//           <span class="visually-hidden">Next</span>
//         </button>
//       </div>
//     </>
//   );
// };

// export default Ceresole;


