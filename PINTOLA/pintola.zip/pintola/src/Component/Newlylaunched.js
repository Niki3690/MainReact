let Newlylaunched = [
  {
    id: 1,
    image:
      "https://www.pintola.in/cdn/shop/files/Choco_400gm_600x.jpg?v=1687856862",
    title: "Dark Chocolate & Cranberry",
    rs: 293,
    ors: 325,
    brand: "400g",
  },
  {
    id: 2,
    image:
      "https://www.pintola.in/cdn/shop/files/Fruit-and-Nut_400gm_0954422b-3b60-4962-bda0-c7a17c90525d_600x.jpg?v=1687856652",
    title: "Fruit & Nut Muesli with 68% ",
    rs: 301,
    ors: 335,
    brand: "400g",
  },
  {
    id: 3,
    image:
      "https://www.pintola.in/cdn/shop/files/1-09_ecacc5ea-7a7b-4938-8882-7d0e8e406ec1_600x.jpg?v=1692339564",
    title: "Jumbo Rolled Oats",
    rs: 175,
    ors: 199,
    brand: "400g",
  },
  {
    id: 4,
    image:
      "https://www.pintola.in/cdn/shop/files/Wholegrain-_-Seed_400gm_600x.jpg?v=1687856811",
    title: "Wholegrain & Seeds Muesli ",
    rs: 292,
    ors: 325,
    brand: "400g",
  },
];
export { Newlylaunched };
