let RecipesData = [
  {
    id: 1,
    image:
      "https://www.pintola.in/cdn/shop/articles/Pintola_noodles_1_a60e6b39-4e08-43b3-a526-f89df28100b5_1000x.jpg?v=1682574587",
    title: "Pintola Peanut Butter Chilli Noodles",
    small: "1 min read",
  },

  {
    id: 2,
    image:
      "https://www.pintola.in/cdn/shop/articles/with_product_2_600x.jpg?v=1682573527",
    title: "Pintola Peanut Butter & Jelly Bread Pudding",
    small: "1 min read",
  },
  {
    id: 3,
    image:
      "https://www.pintola.in/cdn/shop/articles/Pintola_granola_ae91f103-ef8a-4ab5-8c59-62347d251389_600x.jpg?v=1682574657",
    title: "Pintola Peanut Butter Granola Recipe",
    small: "1 min read",
  },
  {
    id: 4,
    image:
      "https://www.pintola.in/cdn/shop/articles/Cashew_Butter_600x.png?v=1620284930",
    title: "Pintola Cashew Butter Oat Meal",
    small: "1 min read",
  },
  {
    id: 5,
    image:
      "https://www.pintola.in/cdn/shop/articles/Salad_With_Almond_Butter_600x.jpg?v=1620284955",
    title: "Pintola Almond Butter Salad",
    small: "1 min read",
  },
  {
    id: 6,
    image:
      "https://www.pintola.in/cdn/shop/articles/Classic_600x.png?v=1620285014",
    title: "Pintola Peanut Butter & Jam Multigrain Sandwich",
    small: "1 min read",
  },
  {
    id: 7,
    image:
      "https://www.pintola.in/cdn/shop/articles/Organic_600x.png?v=1620285059",
    title: "Pintola Smoothie",
    small: "1 min read",
  },
];

export { RecipesData };
