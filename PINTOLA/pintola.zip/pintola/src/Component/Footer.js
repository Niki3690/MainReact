import React from "react";
import "./Footer.css";

const Footer = () => {
  return (
    
    <div className="footer">
      <div style={{ marginTop: 15 }}>
        <img
          src="https://www.pintola.in/cdn/shop/files/Pintola_Logo_PNG_e0a75445-bd35-450f-895e-ece13c165b78_200x.png?v=1668503333"
          className="kkk"
        ></img>
        <br />
        <p className="cata">Follow Us:</p>
        <br />
        <div className="iconv">
          <i className="fa-brands fa-twitter"></i>
          <i className="fa-brands fa-facebook-f"></i>
          <i className="fa-brands fa-youtube"></i>
          <i className="fa-brands fa-instagram"></i>
          <i className="fa-brands fa-linkedin-in"></i>
        </div>
        <br /> <br />
        <p style={{ marginTop: 55 }}>
          {" "}
          <small>© 2023 Pintola.</small>
        </p>
      </div>

      <div>
        <p className="cata text-2xl ">Shop</p>
        <span className="sppp">
          <br />
          <p>All Products</p>
          <p>Premium Nut Butters</p>
          <p>All Natural & Organic</p>
          <p>Wholegrain Rice Cakes</p>
        </span>
      </div>

      <div>
        <p className="cata text-2xl ">Pintola</p>
        <span className="sppp">
          <br />
          <p>About Us</p>
          <p>Privacy Policy</p>
          <p>Terms of Service</p>
          <p>FAQs</p>
          <p>Refund & Cancellation Policy</p>
          <p>Shipping Policy</p>
        </span>
      </div>

      <div>
        <p className="cata text-2xl ">Stay in the loop</p>
        <br />
        <input
          type="email"
          placeholder="Email*"
          style={{
            backgroundColor: "transparent",
            width: 210,
            outline: "none",
          }}
        ></input>
        <br />
        <button className="sign">Sign Up</button>
      </div>

      <div>
        <p className="cata text-2xl ">
          Download Product
          <br /> Catalogue
        </p>
        <br />
        <button className="down">Download</button>
        <br /> <br /> <br /> <br /> <br /> <br />
        <div className="us">
          <button>
            <i
              className="fa-brands fa-whatsapp"
              style={{
                color: "white",
                backgroundColor: "transparent",
                marginRight: 12,
                fontSize: 25,
                marginTop: -45,
              }}
            ></i>
            Chat With us
          </button>
        </div>
      </div>
    </div>
  );
};

export default Footer;
