let AllProductDetail = [
  {
    id: 1,
    image:
      "https://www.pintola.in/cdn/shop/products/1_5a6ffc6c-c20b-4fec-b0f1-be4b4906c468_400x.jpg?v=1670671117",
    title: "All Natural Peanut Butter",
    rs: 163,
    ors: 175,
    brand: "Creamy / 350gm",
  },
  {
    id: 2,
    image:
      "https://www.pintola.in/cdn/shop/products/1_12c8008c-9c77-4e8b-8f9a-c45115b4f687_400x.jpg?v=1670670579",
    title: "All Natural  Peanut Butter",
    rs: 185,
    ors: 199,
    brand: "Crunchy / 350gm",
  },
  {
    id: 3,
    image:
      "https://www.pintola.in/cdn/shop/products/1_3a4749c4-8b9e-4a8f-b62a-5f514a7d703c_400x.jpg?v=1670829499",
    title: "Classic Peanut Butter",
    rs: 149,
    ors: 160,
    brand: "Crunchy / 350gm",
  },
  {
    id: 4,
    image:
      "https://www.pintola.in/cdn/shop/products/1_c593df28-8e17-4372-bf9f-be10f16f9de9_400x.jpg?v=1670672381",
    title: "Dark Chocolate Peanut Butter",
    rs: 185,
    ors: 199,
    brand: "Crunchy / 350gm",
  },
  {
    id: 5,
    image:
      "https://www.pintola.in/cdn/shop/products/1_c593df28-8e17-4372-bf9f-be10f16f9de9_400x.jpg?v=1670672381",
    title: "All  Honey Peanut Butte",
    rs: 185,
    ors: 199,
    brand: "Creamy / 350gm",
  },
  {
    id: 6,
    image: "https://www.pintola.in/cdn/shop/products/1_400x.png?v=1670670079",
    title: "All  Honey Peanut Butte",
    rs: 185,
    ors: 199,
    brand: "Creamy / 350gm",
  },
  {
    id: 7,
    image:
      "https://www.pintola.in/cdn/shop/products/1_7bf0ddec-94d4-4d42-bcb3-4167ffcdbb71_400x.jpg?v=1670829268",
    title: "All  Honey Peanut Butte",
    rs: 185,
    ors: 199,
    brand: "Creamy / 350gm",
  },
  {
    id: 8,
    image:
      "https://www.pintola.in/cdn/shop/products/1_69b3f2d0-b583-42cf-9250-362560e248e1_400x.jpg?v=1670830562",
    title: "All  Honey Peanut Butte",
    rs: 185,
    ors: 199,
    brand: "Creamy / 350gm",
  },
];
export { AllProductDetail };

let Insta = [
  {
    images:
      "https://scontent.cdninstagram.com/v/t51.29350-15/386472777_255833250778913_3631620653260488492_n.jpg?_nc_cat=110&ccb=1-7&_nc_sid=8ae9d6&_nc_ohc=P2olrbW0X0IAX8_gp9i&_nc_ht=scontent.cdninstagram.com&edm=ANo9K5cEAAAA&oh=00_AfAowjuNUmZALMxwU_4jkbyEvzqddNu7RCb53swecxaTtQ&oe=652583CB",
  },
  {
    images:
      "https://scontent.cdninstagram.com/v/t51.29350-15/386261481_725002902795519_448794743144547475_n.jpg?_nc_cat=100&ccb=1-7&_nc_sid=8ae9d6&_nc_ohc=BjcuBZLrt68AX_3I9j_&_nc_ht=scontent.cdninstagram.com&edm=ANo9K5cEAAAA&oh=00_AfAKFGy9HKL0Gq0Q1eDJPm7OqVvC2M9rgN0_NN-rWztChw&oe=65259855",
  },
  {
    images:
      "https://scontent.cdninstagram.com/v/t51.29350-15/385541044_859272828839809_2041053835652146047_n.jpg?_nc_cat=107&ccb=1-7&_nc_sid=8ae9d6&_nc_ohc=Ncv6qEtRUg0AX9MBDsR&_nc_ht=scontent.cdninstagram.com&edm=ANo9K5cEAAAA&oh=00_AfC_WuGSE8RZqlOQljRg6eHx8rZSMcJDjaJ-PU_H0ErC4g&oe=65268B1B",
  },
  {
    images:
      "https://scontent.cdninstagram.com/v/t51.29350-15/384974655_632409799076587_3368233956672059080_n.jpg?_nc_cat=110&ccb=1-7&_nc_sid=8ae9d6&_nc_ohc=5yHbfr2jVcEAX-MAhmF&_nc_ht=scontent.cdninstagram.com&edm=ANo9K5cEAAAA&oh=00_AfC4CLdlGAQqBCTLDP7OWjqaB87r8inm8Ti1--GZsjuVtg&oe=65264B7E",
  },
  {
    images:
      "https://scontent.cdninstagram.com/v/t51.29350-15/385033028_1291010038207497_279810894265490933_n.jpg?_nc_cat=108&ccb=1-7&_nc_sid=8ae9d6&_nc_ohc=jhB1MlTEdtYAX-F_q-N&_nc_ht=scontent.cdninstagram.com&edm=ANo9K5cEAAAA&oh=00_AfCOftfNzCiyjmQqDE3fa0YE4kqPnLvmN6mJF92V-GGviA&oe=6525826F",
  },
  {
    images:
      "https://scontent.cdninstagram.com/v/t51.29350-15/384591631_328551346369822_4488094801447277684_n.jpg?_nc_cat=101&ccb=1-7&_nc_sid=8ae9d6&_nc_ohc=E9EOqeY0hIMAX8lx5OK&_nc_ht=scontent.cdninstagram.com&edm=ANo9K5cEAAAA&oh=00_AfAXgWVOIYwkyEsWZX_HdQHQ4-_JwYxsWW2VYoXLAMBt6g&oe=65258167",
  },
  {
    images:
      "https://scontent.cdninstagram.com/v/t51.29350-15/380778384_271367122524732_3793808599829742011_n.jpg?_nc_cat=105&ccb=1-7&_nc_sid=8ae9d6&_nc_ohc=Mi54wdwQY0oAX9YWtO2&_nc_ht=scontent.cdninstagram.com&edm=ANo9K5cEAAAA&oh=00_AfBHLN-uLLu_Gudo7s5jw3hEHuCZ-UKWiNUQdWeAZ89PmA&oe=65250EFB",
  },
  {
    images:
      "https://scontent.cdninstagram.com/v/t51.29350-15/380793652_847103666772919_3003764934982222816_n.jpg?_nc_cat=101&ccb=1-7&_nc_sid=8ae9d6&_nc_ohc=f25q3V2NJP4AX-iyePF&_nc_oc=AQkuxYHcSS6lBKbs3Zdyg3QB3KtolArGBwTdvHZSnUYYsNSZpujJNCNZGquR63cL1vU&_nc_ht=scontent.cdninstagram.com&edm=ANo9K5cEAAAA&oh=00_AfAmAxRuFtEuQFUm4AXXk7nVB2roKELYzt7wUtMslKOfXw&oe=6525C94D",
  },
  {
    images:
      "https://scontent.cdninstagram.com/v/t51.29350-15/380039022_1516010869225687_7994707611842992958_n.jpg?_nc_cat=107&ccb=1-7&_nc_sid=8ae9d6&_nc_ohc=VZSTylFfkawAX8pNiJp&_nc_ht=scontent.cdninstagram.com&edm=ANo9K5cEAAAA&oh=00_AfB4A3G0aw51uwyaGLGjPCyMbQbsPVfuh3qGZFBbn303Og&oe=65268115",
  },
  {
    images:
      "https://scontent.cdninstagram.com/v/t51.29350-15/379344407_1273299816659002_3715390804724115521_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=8ae9d6&_nc_ohc=slVkr7rk9zcAX-p60h5&_nc_ht=scontent.cdninstagram.com&edm=ANo9K5cEAAAA&oh=00_AfBnVYYQ4mNVai8vJHPvL6z8lAAVuCjNwTbss4TVaDWMAg&oe=6525E4BB",
  },
];

export { Insta };
