import { createContext } from "react";

export let Pintola=createContext()