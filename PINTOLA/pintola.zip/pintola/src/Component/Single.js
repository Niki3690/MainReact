import React from "react";
import { useParams } from "react-router-dom";
import { Link } from "react-router-dom";
import { ProductDetail } from "./ProductDetail";
import { Pintola } from "./Contact";
import { useContext } from "react";
import "./Single.css";

const Single = () => {
  let { Add, Remove } = useContext(Pintola);
  let { id } = useParams();

  let item = ProductDetail.find((p) => p.id == id);
  return (
    <div>
      <div className="single">
        <div>
          <img src={item.image} className="iiimmg" />
        </div>

        <div>
          <p className="namee">{item.title}</p>
          <i class="fa-solid fa-star"></i>
          <i class="fa-solid fa-star"></i>
          <i class="fa-solid fa-star"></i>
          <i class="fa-solid fa-star"></i>
          <i class="fa-solid fa-star"></i>
          <div className="nn">
            <p>Rs.{item.rs}</p>
          </div>
          <div>
            <p className="var">Variant</p>

            <button className="cru">CRUNCHY</button>
            <button className="cre">CREAMY</button>
          </div>

          <div>
            <p className="var">Size</p>

            <button className="gm">350GM</button>
            <button className="kg">1KG</button>
            <button className="kgg">2.5KG</button>
          </div>

          <div>
            <button className="minus">-</button>
          </div>

          <div className="mmm">
            <input type="numbner" className="inputt" value="1" />
          </div>

          <div className="mm">
            <button className="plus">+</button>
          </div>

          <div className="ntb">
            <div>
              <button className="vv" onClick={() => Add(item)}>
                Add to Cart
              </button>
            </div>

            <div>
              <button className="vvv" onClick={() => Remove(item.id)}>
                Remove
              </button>
            </div>
          </div>

          <div>
            <p style={{ width: 545, marginTop: 35 }}>{item.des}</p>
          </div>

          <div style={{ marginTop: 15 }}>
            <p>
              <span style={{ fontWeight: 600 }}>SHELF LIFE:</span>
              {item.lie}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Single;
