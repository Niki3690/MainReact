import React from "react";
import ContactUs from "./ContactUs";

const Call = () => {
  return (
    <div>
      <ContactUs />
      mmm
    </div>
  );
};

export default Call;
