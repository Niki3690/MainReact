let Bestseller = [
  {
    id: 1,
    image:
      "https://www.pintola.in/cdn/shop/products/1_653d166f-df75-4dd1-99ca-c1189cd84f3f_600x.jpg?v=1670830242",
    title: "High Protein Chocolate Peanut Butter",
    rs: 371,
    ors: 749,
    brand: "Crunchy / 1kg",
  },
  {
    id: 2,
    image:
      "https://www.pintola.in/cdn/shop/products/1_18b3b3cb-2d29-4f81-981c-2042968522b6_600x.jpg?v=1670671117",
    title: "All Natural Peanut Butter",
    rs: 163,
    ors: 175,
    brand: "Creamy /350gm",
  },
  {
    id: 3,
    image:
      "https://www.pintola.in/cdn/shop/products/1_c593df28-8e17-4372-bf9f-be10f16f9de9_600x.jpg?v=1670672381",
    title: "Dark Chocolate Peanut Butter",
    rs: 185,
    ors: 199,
    brand: "Crunchy /350gm",
  },
  {
    id: 4,
    image:
      "https://www.pintola.in/cdn/shop/products/Unsalted_600x.jpg?v=1670653747",
    title: "Organic Wholegrain Brown Rice Cakes",
    rs: 144,
    ors: 160,
    brand: "Unsalted",
  },
];
export { Bestseller };
